<?php

namespace Extended\ProjectBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ExtendedProjectBundle extends Bundle
{
}
